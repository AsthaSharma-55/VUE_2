<template>
    <h1>Login page</h1>
</template>

<script>
export default {
    name:"Login"
}
</script>