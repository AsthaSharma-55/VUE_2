<template>
    <h1>Dynamic React Component</h1>
</template>

<script>


export default {
   name:"React"
}
</script>

<style scoped>
h1{
    color:red

}

</style>