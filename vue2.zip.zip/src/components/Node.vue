<template>
    <h1>Dynamic Node Component</h1>
</template>

<script>


export default {
   name:"Node"
}
</script>

<style scoped>
h1{
    color:green

}

</style>