<template>
    <h1>Dynamic Javascript Component</h1>
</template>

<script>
export default {
   name:"Javascript"
}
</script>

<style scoped>
h1{
    color:orange

}

</style>